# coding:utf-8

import sys
import tokenization

tokenizer = tokenization.FullTokenizer(vocab_file="vocab.txt", do_lower_case=True)

def segment(input_file,output_file):

    with open(input_file,'r',encoding='utf-8') as f:
        input = f.readlines()
        segs = []
        for i in input:
            i = eval(i.strip())['source']
            line = i.strip()
            line = tokenization.convert_to_unicode(line)
            if not line:
                segs.append('')
            tokens = tokenizer.tokenize(line)
            segs.append(' '.join(tokens))

    with open(output_file, 'w', encoding='utf-8') as f:
        for i in segs:
            f.write(i)
            f.write('\n')
